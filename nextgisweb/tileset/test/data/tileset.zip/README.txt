© OpenStreetMap contributors (https://www.openstreetmap.org/copyright)           
© Open Database License: https://opendatacommons.org/licenses/odbl/1.0/.     
© NextGIS (data.nextgis.com)       

